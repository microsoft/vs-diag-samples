﻿
namespace MyShuttle.Client.Core.ViewModels
{
    public interface IVehiclesByPriceViewModel 
    {
    }
}
