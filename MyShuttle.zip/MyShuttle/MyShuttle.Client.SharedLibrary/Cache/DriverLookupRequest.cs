﻿namespace MyShuttle.Client.SharedLibrary.Cache
{
    public class DriverLookupRequest
    {
        public int id { get; set; }
        public string name { get; set; }
        public int sequenceId { get; set; }
    }
}