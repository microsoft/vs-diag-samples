﻿using System.Windows.Controls;

namespace MyShuttle.Client.Desktop.Views
{
    public partial class MainView : Page
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
