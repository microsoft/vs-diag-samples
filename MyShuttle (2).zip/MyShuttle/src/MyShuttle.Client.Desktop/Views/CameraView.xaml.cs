﻿using System.Windows.Controls;

namespace MyShuttle.Client.Desktop.Views
{
    public partial class CameraView : Page
    {
        public CameraView()
        {
            InitializeComponent();
        }
    }
}
