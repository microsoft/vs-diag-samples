﻿
namespace MyShuttle.Client.Core.ViewModels.InterfacesForDependencyInjection
{
    public interface IVehiclesViewModel 
    {
    }
}
