﻿//using Cirrious.MvvmCross.ViewModels;

namespace MyShuttle.Client.Core.ViewModels.InterfacesForDependencyInjection
{
    //public interface ISettingsViewModel : IMvxViewModel
    //{
    //}
}
