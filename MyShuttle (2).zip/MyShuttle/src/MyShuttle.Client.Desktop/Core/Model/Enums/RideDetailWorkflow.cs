﻿namespace MyShuttle.Client.Core.Model.Enums
{
    public enum RideDetailWorkflow
    {
        Resume, Rate
    }
}
