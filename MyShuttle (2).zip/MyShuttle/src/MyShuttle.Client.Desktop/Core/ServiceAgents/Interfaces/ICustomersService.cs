﻿
using MyShuttle.Client.Core.ServiceAgents.Interfaces;
using MyShuttle.Client.Services.Interfaces;

namespace MyShuttle.Client.Core.ServiceAgents
{
    public interface ICustomersService : IUpdatableUrl
    {
    }
}
