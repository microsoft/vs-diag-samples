﻿using MyShuttle.Client.Core.DocumentResponse;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyShuttle.Client.Desktop.ViewModels
{
    public class EditDriverViewModel : BaseViewModel
    {
        public static Driver CurrentDriver { get; set; }

        public override void Load()
        {
            
        }

        public override void Update(string view)
        {
            
        }
    }
}
