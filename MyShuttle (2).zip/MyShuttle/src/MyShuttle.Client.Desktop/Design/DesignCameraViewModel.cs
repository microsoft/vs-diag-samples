﻿
namespace MyShuttle.Client.Desktop
{
    public class DesignCameraViewModel
    {
        public DesignDetailsViewModel Details { get; set; }

        public DesignCameraViewModel()
        {
            Details = new DesignDetailsViewModel();
        }
    }
}
