﻿namespace MyShuttle.Client.Core.DocumentResponse
{
    public enum VehicleStatus
    {
        Unknown = 0,
        Occupied = 1,
        Free = 2,
    }
}